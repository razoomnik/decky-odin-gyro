# Odin Gyro

Small Decky Loader plugin for AYN Odin 3 running Armada.

Features:

- **Install / Update Gyro Fix** — runs the tested Odin 3 gyro recovery script for the currently installed Armada kernel. If `~/armada-scripts` is a Git clone, the backend first tries to download the latest `scripts/odin3-gyro-recovery.sh` from that repository; otherwise it uses the bundled tested recovery script.
- **Calibrate Gyro** — restarts the sensor stack, waits for `snsfeed` to actually start, keeps a short zero-bias sampling window while the device is motionless, then restarts InputPlumber.

The plugin backend requires Decky's `_root` flag because the recovery process builds and installs a kernel module and manages system services.

Calibration: place the Odin 3 on a stable surface and do not move it until the plugin reports completion.
